module.exports = "@acme/private-utils@1.2.3"
