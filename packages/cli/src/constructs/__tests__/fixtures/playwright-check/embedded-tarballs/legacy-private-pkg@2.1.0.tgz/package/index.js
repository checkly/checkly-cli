module.exports = "legacy-private-pkg@2.1.0"
